pyBarcode SVGWriter
===================

Creates barcodes as (compressed) SVG objects.

Special Options
---------------

In addition to the common writer options you can give the following
special option.

Special Option:
~~~~~~~~~~~~~~~

:compress:
    Boolean value to output a compressed SVG object (.svgz).
    Defaults to **False**.

